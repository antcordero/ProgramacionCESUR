package ej3;

public enum CategoriaPlato {
    ENTRANTE, PLATO_PRINCIPAL, POSTRE
}
