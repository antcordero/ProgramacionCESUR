package ej1;

public enum Rol {
    ADMIN, GERENTE, EMPLEADO
}
