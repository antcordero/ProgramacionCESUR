package ej2;

public enum CategoriaProducto {
    ELECTRONICA, ROPA, ALIMENTACION
}
