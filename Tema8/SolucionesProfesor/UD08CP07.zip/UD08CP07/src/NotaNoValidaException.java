public class NotaNoValidaException extends Exception {
    public NotaNoValidaException(String msg) {
        super(msg);
    }
}
