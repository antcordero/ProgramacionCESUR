public class NombreVacioException extends Exception {
    public NombreVacioException(String msg) {
        super(msg);
    }
}
