public class LimiteNumero extends Exception {
    public LimiteNumero(String message) {
        super(message);
    }
}
