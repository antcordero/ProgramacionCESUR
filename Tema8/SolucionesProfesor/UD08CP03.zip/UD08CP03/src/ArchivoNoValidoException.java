public class ArchivoNoValidoException  extends Exception{
    public ArchivoNoValidoException(String message) {
        super(message);
    }
}
