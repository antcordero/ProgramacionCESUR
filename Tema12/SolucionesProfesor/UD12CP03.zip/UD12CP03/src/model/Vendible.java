package model;

public interface Vendible {
    double calcularPrecioFinal();
}
