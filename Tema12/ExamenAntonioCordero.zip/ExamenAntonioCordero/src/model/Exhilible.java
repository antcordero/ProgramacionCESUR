package model;

public interface Exhilible {
    boolean esExhibible();
}
