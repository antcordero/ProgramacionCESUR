package TipoCEjercicio1;

public class CuentaBloqueadaException extends Exception{

    public CuentaBloqueadaException(String msg) {
        super(msg);
    }
}
