package TipoCEjercicio1;

public class CredencialesIncorrectasException extends Exception {
    public CredencialesIncorrectasException(String msg) {
        super(msg);
    }
}
