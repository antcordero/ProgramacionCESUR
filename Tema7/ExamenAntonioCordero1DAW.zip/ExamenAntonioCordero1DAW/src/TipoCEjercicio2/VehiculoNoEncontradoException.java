package TipoCEjercicio2;

public class VehiculoNoEncontradoException extends Exception{
    public VehiculoNoEncontradoException(String msg) {
        super(msg);
    }
}
