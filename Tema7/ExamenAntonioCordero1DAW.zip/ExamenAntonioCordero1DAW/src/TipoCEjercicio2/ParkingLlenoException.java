package TipoCEjercicio2;

public class ParkingLlenoException extends Exception{
    public ParkingLlenoException(String  msg) {
        super(msg);
    }
}
