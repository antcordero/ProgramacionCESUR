package TipoCEjercicio2;

public class VehiculoDuplicadoException extends Exception {

    public VehiculoDuplicadoException(String mesg) {
        super(mesg);
    }
}
