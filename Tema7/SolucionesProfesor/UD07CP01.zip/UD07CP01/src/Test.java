import java.sql.SQLOutput;

public class Test {
    public static void main(String[] args) {
        DivisionPorCero div = new DivisionPorCero();
        div.division(5,1);
        System.out.println("\tVolviendo de main");
    }
}
