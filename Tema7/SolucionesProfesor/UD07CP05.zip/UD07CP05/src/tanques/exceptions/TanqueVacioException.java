package tanques.exceptions;

public class TanqueVacioException extends SecurityException {
	public TanqueVacioException(String msg) {
		super(msg);
	}
}
