public class BonificacionInvalidaException extends Exception {
    public BonificacionInvalidaException(String mensaje) {
        super(mensaje);
    }
}
