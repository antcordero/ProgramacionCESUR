public class SaldoInvalidoException extends Exception {
    public SaldoInvalidoException(String mensaje) {
        super(mensaje);
    }
}