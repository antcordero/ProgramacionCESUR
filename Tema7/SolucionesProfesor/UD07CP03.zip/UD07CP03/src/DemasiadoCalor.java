public class DemasiadoCalor extends Limites{
    public DemasiadoCalor(String message) {
        super(message);
    }
}
