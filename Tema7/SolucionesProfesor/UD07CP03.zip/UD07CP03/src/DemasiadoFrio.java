public class DemasiadoFrio  extends Limites{
    public DemasiadoFrio(String message) {
        super(message);
    }
}
