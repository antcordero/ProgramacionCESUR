public class Limites extends Exception{
    public Limites(String message) {
        super(message);
    }
}
