public interface Camara {
    void realizarFoto(String resolucion);
}
