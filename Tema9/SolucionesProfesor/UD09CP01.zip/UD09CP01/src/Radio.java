public interface Radio {
    void escucharSintonia(String sintonia);
}
