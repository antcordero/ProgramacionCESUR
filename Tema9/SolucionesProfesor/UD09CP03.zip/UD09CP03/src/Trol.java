public class Trol extends Criatura{
    public static int VIDAMAX_TROL=14;
    public static int FUERZA_TROL=5;
    public Trol(String nombre) {
        super(nombre, FUERZA_TROL, VIDAMAX_TROL);
    }
}
