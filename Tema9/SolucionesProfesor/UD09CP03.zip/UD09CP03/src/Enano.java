public class Enano  extends Criatura {
    public static int VIDAMAX_ENANO=10;
    public static int FUERZA_ENANO=10;
    public Enano(String nombre) {
        super(nombre, FUERZA_ENANO, VIDAMAX_ENANO);
    }
}
