public class Elfo extends Criatura {
    public static int VIDAMAX_ELFO=20;
    public static int FUERZA_ELFO=3;

    public Elfo(String nombre) {
        super(nombre, FUERZA_ELFO, VIDAMAX_ELFO);
    }
}
