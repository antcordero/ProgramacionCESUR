public class SmartPhone extends Dispositivo {
    public void hacerLlamada(String numero){
        System.out.println("Llamando al número " + numero);
    }
}
