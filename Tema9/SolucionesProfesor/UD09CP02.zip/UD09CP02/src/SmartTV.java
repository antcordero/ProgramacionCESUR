public class SmartTV extends Dispositivo {
   public void reproducirVideo(String video){
       System.out.println("Reproduciendo video " + video);
   }
}
