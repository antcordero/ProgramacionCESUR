public interface Conectable {
    void conectarWifi();
    void desconectarWifi();
    boolean estaConectado();
}
