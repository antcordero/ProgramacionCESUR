public interface Mostrable {
    void mostrarDetalles();
}
