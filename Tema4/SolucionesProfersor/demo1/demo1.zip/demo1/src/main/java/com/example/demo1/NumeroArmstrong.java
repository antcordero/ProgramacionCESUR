package com.example.demo1;

//"Escribe un programa que determine si un número ingresado por el
        //usuario es un número de Armstrong. Un número de Armstrong de n dígitos es aquel
        //ue es igual a la suma de sus dígitos elevados a la potencia n.
        //Ejemplo:
        //Escribe un número: 371
       //Es un número de Armstrong"
import java.util.Scanner;

public class NumeroArmstrong {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Escribe un número: ");
        int numero = scanner.nextInt();

        // Calcula la cantidad de dígitos en el número
        int numeroAbsoluto = Math.abs(numero);
        int n = String.valueOf(numeroAbsoluto).length();

        int suma = 0;
        int temp = numeroAbsoluto;

        // Calcula la suma de los dígitos elevados a la potencia n
        while (temp > 0) {
            int digito = temp % 10;        // Extrae el último dígito
            suma += Math.pow(digito, n);   // Eleva el dígito a la potencia n y suma el resultado
            temp /= 10;                    // Elimina el último dígito
        }

        // Verifica si la suma es igual al número original
        if (suma == numeroAbsoluto) {
            System.out.println(numero + " es un número de Armstrong.");
        } else {
            System.out.println(numero + " no es un número de Armstrong.");
        }

        scanner.close();
    }
}
