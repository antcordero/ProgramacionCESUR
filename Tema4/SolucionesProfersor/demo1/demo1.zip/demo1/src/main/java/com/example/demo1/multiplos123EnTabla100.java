package com.example.demo1;

import java.util.Scanner;

public class multiplos123EnTabla100 {
    public static void main(String[]args){
    Scanner scanner= new Scanner(System.in);
    System.out.print("");
    }
}
