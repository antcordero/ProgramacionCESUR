import java.util.Scanner;

public class ejercicio4 {

    public static void main(String[] args){
        Scanner scanner = new Scanner(System.in);

        System.out.print("Escribe un número: ");
        int numero = scanner.nextInt();


        int numeroAbsoluto = Math.abs(numero);
        int n = String.valueOf(numeroAbsoluto).length();

        int suma = 0;
        int temp = numeroAbsoluto;


        while (temp > 0) {
            int digito = temp % 10;
            suma += Math.pow(digito, n);
            temp /= 10;
        }


        if (suma == numeroAbsoluto) {
            System.out.println(numero + " es un número de Armstrong.");
        } else {
            System.out.println(numero + " no es un número de Armstrong.");
        }

        scanner.close();
    }
}
