package com.example.demo1;

//Escribe un programa que lea un número entero y calcule la suma de sus dígitos.
import java.util.Scanner;

public class SumaDeDigitos {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce un número entero: ");
        int numero = scanner.nextInt();

        int suma = 0;
        int numeroAbsoluto = Math.abs(numero); // Aseguramos que el número sea positivo para calcular los dígitos

        // Calcular la suma de los dígitos
        while (numeroAbsoluto > 0) {
            suma += numeroAbsoluto % 10; // Extrae el último dígito y lo suma
            numeroAbsoluto /= 10;        // Elimina el último dígito
        }

        System.out.println("La suma de los dígitos es: " + suma);

        scanner.close();
    }
}

