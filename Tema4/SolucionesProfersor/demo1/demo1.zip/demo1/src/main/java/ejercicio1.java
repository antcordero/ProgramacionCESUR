import java.util.Scanner;

public class ejercicio1 {
    public static void main(String[] args) {

        int resultado = 0;

        for (int i = 1; i <= 100; i++) {

            resultado+=i;
        }
        System.out.println("Resultado: "+resultado);
    }
}
