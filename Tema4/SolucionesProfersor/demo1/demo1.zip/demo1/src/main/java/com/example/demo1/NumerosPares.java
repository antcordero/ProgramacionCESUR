package com.example.demo1;

//Escribe un programa en Java que imprima todos los números pares del  1 al 50
public class NumerosPares {
    public static void main(String[] args) {
        System.out.println("Números pares del 1 al 50:");
        for (int i = 1; i <= 50; i++) {
            if (i % 2 == 0) {
                System.out.println(i);
            }
        }
    }
}
