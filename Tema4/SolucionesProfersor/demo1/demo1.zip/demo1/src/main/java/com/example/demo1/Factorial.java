package com.example.demo1;

        //Escribe un programa en Java que lea un número entero positivo introducido
        //por el usuario y calcule su factorial. El factorial de un número se calcula de la siguiente
        //forma: se deben multiplicar todos los números enteros y positivos que hay entre el
        //número introducido y el número 1:
import java.util.Scanner;

public class Factorial {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Introduce un número entero positivo: ");
        int numero = scanner.nextInt();

        if (numero < 0) {
            System.out.println("Por favor, introduce un número positivo.");
        } else {
            long factorial = 1;
            for (int i = 1; i <= numero; i++) {
                factorial *= i;
            }

            System.out.println("El factorial de " + numero + " es: " + factorial);
        }

        scanner.close();
    }
}

