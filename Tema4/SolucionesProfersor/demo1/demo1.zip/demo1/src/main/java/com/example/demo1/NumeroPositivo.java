package com.example.demo1;

import java.util.Scanner;

public class NumeroPositivo {
    public static void main(String[]args) {
        Scanner scanner= new Scanner(System.in);
        int numero;
        do {
        System.out.println("Inserte un numero psitivo");
        numero= scanner.nextInt();
        } while(numero<=0);
        System.out.println("El numero escrito es positivo" + numero);
        scanner.close();

    }
}
