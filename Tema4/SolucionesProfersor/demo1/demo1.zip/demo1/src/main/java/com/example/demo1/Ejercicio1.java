package com.example.demo1;

import java.util.Scanner;

public class Ejercicio1 {
public  static void main(String[]args) {
    Scanner scanner= new Scanner(System.in);
    System.out.print("Indique el numero 1");
    int numero1 = scanner.nextInt();
    System.out.print("Indique el numero2");
    int numero2 = scanner.nextInt();
    System.out.print("indique el numero3");
    int numero3 = scanner.nextInt();
    int mayor = numero1;

    if (numero2>mayor) {
        mayor= numero2;
    }
    if (numero3>mayor) {

        mayor=numero3;
        System.out.print("El número mas grande es" + mayor );
    }

    }

}
